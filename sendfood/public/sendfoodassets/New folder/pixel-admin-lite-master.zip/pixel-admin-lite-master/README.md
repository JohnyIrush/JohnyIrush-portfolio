<!-- # pixel-admin-lite -->
<!-- Heading of Template -->
<h1>
  <a href="https://www.wrappixel.com/demos/free-admin-templates/pixel-admin-lite/pixel-html/index.html">Pixel Bootstrap Admin Lite</a>
</h1>

<!-- Main image of Template -->
<a target="_blank" href="https://www.wrappixel.com/wp-content/uploads/edd/2020/04/pixel-admin-lite-y.jpg">
  <img src="https://www.wrappixel.com/wp-content/uploads/edd/2020/04/pixel-admin-lite-y.jpg" />
</a>

<!-- Description of Template -->
<p>
 Lorem ipsume
</p>

<!-- <h4><a href="https://wrappixel.com/demos/free-admin-templates/pixel-admin-lite/pixel-html/index.html">Free Version Demo Link</a></h4>
## Pro Version
<a href="https://www.wrappixel.com/templates/pixeladmin/"><img src="https://www.wrappixel.com/wp-content/uploads/2019/01/pixel-admin-bootstrap-nw-1.jpg"/></a><br/>
<h4><a href="https://www.wrappixel.com/demos/admin-templates/pixeladmin/inverse/index.html">Demo</a></h4> -->

<!-- Resources of Template -->
<h2>Resources</h2>
<ul>
<li>  
  Live Demo: <a href="https://www.wrappixel.com/demos/free-admin-templates/pixel-admin-lite/pixel-html/index.html" rel="nofollow">https://www.wrappixel.com/demos/free-admin-templates/pixel-admin-lite/pixel-html/index.html</a>
</li>
<li>
    Download Page: <a href="https://www.wrappixel.com/templates/pixel-admin-lite/" rel="nofollow">
  https://www.wrappixel.com/templates/pixel-admin-lite/</a>
</li>
<li>
    <a href="https://www.wrappixel.com/templates/wrapkit/#demos" rel="nofollow">WrapKit </a>Complete UI Kit - For Website Projects
</li>
</ul>

<!-- Licensing of Template -->
<h2>Licensing</h2>
<ul>
  <li>
    <p>Copyright 2020 Wrappixel (<a href="https://www.wrappixel.com/" rel="nofollow">https://www.wrappixel.com/</a>)</p>
  </li>
  <li>
    <p>Licensed under MIT (<a href="https://www.wrappixel.com/license/">https://www.wrappixel.com/license/</a>)</p>
  </li>
</ul>


<!-- Upgrade to Premium version of Template -->
<h2>Upgrade to Premium version</h2>
<a target="_blank" href="https://www.wrappixel.com/templates/pixeladmin/">
  <img src="https://www.wrappixel.com/wp-content/uploads/edd/2020/04/pixel-bootstrap-admin-y.jpg" />
</a>
<p>
   Checkout our premium version of Pixel Bootstrap Admin for lots more features and ready to use page templates.<br>
   <a href="https://www.wrappixel.com/demos/admin-templates/pixeladmin/inverse/index.html">Check Live Preview</a> | <a href="https://www.wrappixel.com/templates/pixeladmin/">Download</a>
</p>

<!-- Useful Links of Template -->
<h2>Useful Links</h2>
<ul>
<li><a href="https://www.wrappixel.com/templates/category/admin-template/">Free Admin Templates</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/">Bootstrap Templates</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/bootstrap-admin-templates/">Bootstrap 4 Dashboard</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/angular-templates/">Angular Material Template</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/react-templates/">React Templates</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/vuejs-templates/">Vue Templates</a> from WrapPixel</li>
<li><a href="https://www.wrappixel.com/templates/category/free-templates/">Free Website Templates</a> from WrapPixel</li>
</ul>

<!-- Social Media of Wrappixel -->
<h2>Social Media</h2>
<p>Facebook: <a href="https://www.facebook.com/wrappixel">https://www.facebook.com/wrappixel</a></p>
<p>Twitter: <a href="https://twitter.com/wrappixel">https://twitter.com/wrappixel</a></p>
<p>Medium: <a href="https://medium.com/wrappixel">https://medium.com/wrappixel</a></p>
